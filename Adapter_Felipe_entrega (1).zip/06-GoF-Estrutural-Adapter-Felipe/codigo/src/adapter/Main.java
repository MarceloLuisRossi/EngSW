package adapter;

/**
 * CLIENT: só conhece a interface ProcessadorPagamento.
 */
public class Main {
    public static void main(String[] args) {
        ProcessadorPagamento pagamento = new GatewayAdapter(new GatewayLegado());
        pagamento.pagar(149.90);
    }
}

package adapter;

/**
 * TARGET: interface que o nosso sistema conhece e espera usar.
 */
public interface ProcessadorPagamento {
    void pagar(double valorReais);
}

# GoF Estrutural: Adapter

**Autor:** Felipe Agazzi
**Disciplina:** Engenharia de Software, 2026/2

## Conteúdo

| Arquivo | Descrição |
|---|---|
| `Adapter_GoF_Felipe.pptx` | Slides da apresentação (5 a 10 min) |
| `codigo/src/adapter/` | Exemplo de implementação em Java |

## O padrão em uma frase

O **Adapter** converte a interface de uma classe em outra interface que o cliente espera, permitindo que classes incompatíveis trabalhem juntas sem que nenhuma delas seja alterada.

## Problema

O sistema processa pagamentos pela interface `ProcessadorPagamento` (`pagar(double valorReais)`), mas precisa usar um gateway de terceiros (`GatewayLegado`) cujo método é `efetuarCobranca(long centavos, String moeda)`. O código de terceiros não pode ser modificado.

## Estrutura (Object Adapter)

```
Client ──► «interface» Target            ProcessadorPagamento
                 ▲ implementa
              Adapter ──contém──► Adaptee  GatewayAdapter ──► GatewayLegado
```

| Papel | Classe no exemplo |
|---|---|
| Target | `ProcessadorPagamento` |
| Adaptee | `GatewayLegado` |
| Adapter | `GatewayAdapter` |
| Client | `Main` |

## Como executar

**Na IDE (IntelliJ, Eclipse ou VS Code):** abra a pasta `codigo`, marque `src` como pasta de código-fonte e execute `adapter.Main`.

**No terminal:**

```bash
cd codigo/src
javac -d ../out adapter/*.java
java -cp ../out adapter.Main
```

Saída esperada:

```
[GatewayLegado] Cobrança de 14990 centavos em BRL
```

## Referências

- GAMMA, E.; HELM, R.; JOHNSON, R.; VLISSIDES, J. *Padrões de Projeto: Soluções Reutilizáveis de Software Orientado a Objetos*. Porto Alegre: Bookman, 2000.
- Refactoring.Guru: Adapter. https://refactoring.guru/pt-br/design-patterns/adapter
- Exemplo real na biblioteca Java: `java.io.InputStreamReader`. https://docs.oracle.com/javase/8/docs/api/java/io/InputStreamReader.html
